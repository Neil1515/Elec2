
package com.example.midtermapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
public class MainActivity3 extends AppCompatActivity {

        private EditText editText;
        private Button addButton;
        private ListView listView;
        private Button deleteButton;
        private ArrayList<String> listItems;
        private ArrayAdapter<String> adapter;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main3);

            editText = findViewById(R.id.editText);
            addButton = findViewById(R.id.addButton);
            listView = findViewById(R.id.listView);
            deleteButton = findViewById(R.id.deleteButton);

            listItems = new ArrayList<String>();
            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, listItems);
            listView.setAdapter(adapter);
            listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

            addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String newItem = editText.getText().toString();
                    if (!newItem.equals("")) {
                        listItems.add(newItem);
                        adapter.notifyDataSetChanged();
                        editText.setText("");
                    } else {
                        Toast.makeText(getApplicationContext(), "Please enter a task.", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String selectedItem = ((String)parent.getItemAtPosition(position)).toString();
                    Toast.makeText(getApplicationContext(), selectedItem, Toast.LENGTH_SHORT).show();
                }
            });

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
                    if (checkedItemPositions != null && checkedItemPositions.size() > 0) {
                        for (int i = adapter.getCount() - 1; i >= 0; i--) {
                            if (checkedItemPositions.get(i)) {
                                adapter.remove(adapter.getItem(i));
                            }
                        }
                        listView.clearChoices();
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(getApplicationContext(), "Please select at least one task to delete.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

